# MightyMinerV2
