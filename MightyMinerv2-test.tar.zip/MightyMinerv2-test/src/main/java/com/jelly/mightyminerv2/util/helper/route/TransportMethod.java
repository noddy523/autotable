package com.jelly.mightyminerv2.util.helper.route;

// Todo: Rename
public enum TransportMethod {
    AOTV,           // Right Click Aotv/Aote
    ETHERWARP,       // Shift + Right Click Aotv/Aote
    WALK,           // Walks Between Nodes (Add it after pathfinder)
}
